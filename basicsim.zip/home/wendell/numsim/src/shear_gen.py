import sys, decimal, numpy as np
from numpy import array

import jammed

from optparse import OptionParser
parser = OptionParser()

parser.add_option('-N', type=int, default=6)
parser.add_option('-r', '--ratio', type=float, default=1.4)
parser.add_option('-n', '--mix', type=float, default=0.5,
            help='Fraction of small particles')
parser.add_option('--seed', type=int, default=None)
parser.add_option('-H', '--shear', type=float, default=0.0)

parser.add_option('-P', '--pressure', type=float, default=1e-8)
parser.add_option('--dgamma', type=float, default=1e-7)
parser.add_option('--dt', type=float, default=1e-1)
parser.add_option('--bondk', type=float, default=1.0)
parser.add_option('--CGerr', type=float, default=1e-14)

parser.add_option('--phi0', type=float, default=1e-3)
parser.add_option('--firstpressure', type=float, default=1e-4)
parser.add_option('--Psteps', type=int, default=5)
parser.add_option('--kappa', type=float, default=10.0)
parser.add_option('--kmax', type=int, default=1000)
parser.add_option('--secmax', type=int, default=40)
parser.add_option('--seceps', type=float, default=1e-20)
parser.add_option('--amax', type=float, default=2.0)
parser.add_option('--dxmax', type=float, default=100)
parser.add_option('--stepmax', type=float, default=1e-3)
parser.add_option('--long', action='store_true')

parser.add_option('--printn', type=int, default=100000)
parser.add_option('--checkn', type=int, default=1000)

parser.add_option('-O', '--outfilename', default='test/test_compress.npz')

opts,args = parser.parse_args()
fname, = args if len(args) > 0 else (None,)

if opts.long:
    import sim2dlong as sim2d
    from sim2dlong import *
else:
    import sim2d
    from sim2d import *
    
seedn = seed(opts.seed) if (opts.seed is not None and opts.seed >= 0) else seed()
np.random.seed(seedn)
    
argv = list(sys.argv)
if opts.seed is None:
    argv.extend(['--seed',str(seedn)])
    opts.seed = seedn
if opts.shear < 0:
    shear = np.random.rand()
    print("Shearing at", shear)
    #argv.extend(['--shear',str(shear)])
    #opts.shear = shear
else:
    shear = opts.shear
print(*argv, sep=' ', file=sys.stderr)
sys.stderr.flush()

outfilename = opts.outfilename.format(**opts.__dict__)
print('output to', repr(outfilename))

sigmas = np.array([1.0]*(opts.N //2) + [opts.ratio]*(opts.N - (opts.N //2)))
V0 = np.sum(sigmas**2)*np.pi/4
L = np.sqrt(V0/opts.phi0)

#-----------------------------------------------------------------------
# Simulation
masses = list(sigmas**2)

bx = LeesEdwardsBox(vec(L,L), shear)
atoms = atomvec(masses)
neighbors = neighborlist(bx, max(sigmas), max(sigmas)*1.4)
hertz = Hertzian(neighbors)

for a, s in zip(atoms, sigmas):
    a.x = bx.randLoc()
    hertz.add(HertzianAtom(a,1.0, s,2.0))
    
collec = collectionNLCG(bx, opts.dt, opts.pressure, [atoms], [hertz], [neighbors], [], 
        opts.kappa, opts.kmax,  opts.secmax,   opts.seceps)
collec.setamax(opts.amax)
collec.setdxmax(opts.dxmax)
collec.setstepmax(opts.stepmax)

def savefile(locs, outfilename=outfilename):
    g,t,r,s = zip(*locs)
    np.savez_compressed(outfilename, gammas = g, ts = t, rs = r, sigmas = s)

def pack_stats(bx=bx, atoms=atoms):
    L = np.sqrt(bx.V())
    for a in atoms:
        a.x = bx.diff(a.x, vec(0,0))
    
    curxs = np.array([a.x.X/L for a in atoms])
    curys = np.array([a.x.Y/L for a in atoms])
    cursigmas = (sigmas / L)
    fl_idx = jammed.floater_indices(curxs, curys, cursigmas, 0.0)
    floaters = np.sum(fl_idx)
    Nc = Nc = jammed.num_contacts(curxs[~fl_idx],curys[~fl_idx],cursigmas[~fl_idx],tol=0.0)
    Nc_exp = max((len(sigmas) - floaters)*2-1, 1)
    
    return Nc, Nc_exp, floaters

def printstatus(steps, bx=bx, collec=collec, atoms=atoms):
    global neighbors, hertz
    global Vs, phi0
    
    Nc, Nc_exp, floaters = pack_stats()
    
    print(('φ=%12.6g, H=%8.3g, U=%8.3g, P=%8.3g, F=%8.3g, KE %8.3g\n' + 
           '         Nc=%4d/%4d, overlaps=%8.3g steps %9d')
            % (
                (V0/bx.V()),
                collec.Hamiltonian() / atoms.size(), collec.potentialenergy() / atoms.size(),
                collec.pressure(), np.mean([a.f.mag() for a in atoms]),
                collec.vdotv()/atoms.size(),
                Nc, Nc_exp, 
                hertz.energy(bx) / atoms.size(), steps))
    
locs = []
steps = 0

collec.setForces(True, True)
printstatus(steps)

Ps = np.logspace(np.log10(opts.firstpressure), 
                    np.log10(opts.pressure), opts.Psteps)

curm = opts.printn
for P in Ps:
    collec.setP(P)
    while ((np.mean([a.f.mag() for a in atoms]) > opts.CGerr) or not
        (P / 2 < collec.pressure() < P * 2)):
        for i in range(opts.checkn):
            collec.timestep()
        steps += opts.checkn
        
        if steps >= curm:
            printstatus(steps)
            curm += opts.printn
            rs = np.array([(a.x.X, a.x.Y) for a in atoms])
            L = bx.L()
            myloc = (shear, steps, rs/L, sigmas/L)
            locs.append(myloc)
            savefile(locs)
    
    printstatus(steps)
    if steps > curm - (opts.printn//2):
        curm += opts.printn
    print("Finished, P=%8.2g, φ=%14.12g" % (collec.pressure(), V0 / bx.V()))


rs = np.array([(a.x.X, a.x.Y) for a in atoms])
L = bx.L()
myloc = (shear, steps, rs/L, sigmas/L)
locs.append(myloc)
savefile(locs)
